var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","d64f5bbe-996d-4a48-9449-35fba4d7f46f","a83fd47c-e6b6-473d-a48d-f4cfa3ebec00","d74f8ce0-cad1-4a87-90b5-4f1aafed5d96","d67f4929-19a4-4c6c-8f49-da4670750124","2d453baa-33d7-4d68-8461-678f6f8904c3","7ba56a96-a481-4ba3-86c2-736222eaa5ec","9afbd7d5-419a-4aef-bb3b-48e2b992984b","5c7c1bb1-575f-4d23-89c0-73dc1eb801ef"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"GjZO24.5fNu.qjIj1mRYUyRTaTcYpvE3","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"K6NWgISBXgx1Nz5d_lncK9KiM7CGvR9r","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"_AAy_sVi.jK9yHMLlYQSRx9Huz_mm7jM","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"d64f5bbe-996d-4a48-9449-35fba4d7f46f":{"name":"city_1","sourceUrl":"assets/api/v1/animation-library/gamelab/OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF/category_backgrounds/city.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OGMmhuYDozWZhjtNHQkjhdvs2Ge_Q0UF/category_backgrounds/city.png"},"a83fd47c-e6b6-473d-a48d-f4cfa3ebec00":{"name":"ocean","sourceUrl":"assets/api/v1/animation-library/gamelab/liip36Uzd.UEskze8YUtuWMvk3veS2QD/category_backgrounds/background_underwater_11.png","frameSize":{"x":400,"y":399},"frameCount":1,"looping":true,"frameDelay":2,"version":"liip36Uzd.UEskze8YUtuWMvk3veS2QD","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/liip36Uzd.UEskze8YUtuWMvk3veS2QD/category_backgrounds/background_underwater_11.png"},"d74f8ce0-cad1-4a87-90b5-4f1aafed5d96":{"name":"fish","sourceUrl":"assets/api/v1/animation-library/gamelab/nymJ0xt9QPE.HuR6qX3X4KBoH32ICAGz/category_animals/tropicalfish_04.png","frameSize":{"x":400,"y":324},"frameCount":1,"looping":true,"frameDelay":2,"version":"nymJ0xt9QPE.HuR6qX3X4KBoH32ICAGz","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":324},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nymJ0xt9QPE.HuR6qX3X4KBoH32ICAGz/category_animals/tropicalfish_04.png"},"d67f4929-19a4-4c6c-8f49-da4670750124":{"name":"cactus","sourceUrl":"assets/api/v1/animation-library/gamelab/3rgTZuYQvQmKa2v_StGG3Yp369cx.REH/category_video_games/cactus_02.png","frameSize":{"x":399,"y":377},"frameCount":1,"looping":true,"frameDelay":2,"version":"3rgTZuYQvQmKa2v_StGG3Yp369cx.REH","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":399,"y":377},"rootRelativePath":"assets/api/v1/animation-library/gamelab/3rgTZuYQvQmKa2v_StGG3Yp369cx.REH/category_video_games/cactus_02.png"},"2d453baa-33d7-4d68-8461-678f6f8904c3":{"name":"shell","sourceUrl":"assets/api/v1/animation-library/gamelab/FZL9r53_evAXtea.gLFfJ8j0vmvYJNY./category_aquatic_objects/shell_12.png","frameSize":{"x":374,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"FZL9r53_evAXtea.gLFfJ8j0vmvYJNY.","categories":["aquatic_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":374,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/FZL9r53_evAXtea.gLFfJ8j0vmvYJNY./category_aquatic_objects/shell_12.png"},"7ba56a96-a481-4ba3-86c2-736222eaa5ec":{"name":"she","sourceUrl":"assets/api/v1/animation-library/gamelab/OQfc0Mb0lAe7nQcY6dCDhk3sbR6PrK52/category_aquatic_objects/shell_10.png","frameSize":{"x":400,"y":360},"frameCount":1,"looping":true,"frameDelay":2,"version":"OQfc0Mb0lAe7nQcY6dCDhk3sbR6PrK52","categories":["aquatic_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":360},"rootRelativePath":"assets/api/v1/animation-library/gamelab/OQfc0Mb0lAe7nQcY6dCDhk3sbR6PrK52/category_aquatic_objects/shell_10.png"},"9afbd7d5-419a-4aef-bb3b-48e2b992984b":{"name":"line","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"4x2G5Wl5NpYzj4YVetnyJhXmxDkYxMwN","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/9afbd7d5-419a-4aef-bb3b-48e2b992984b.png"},"5c7c1bb1-575f-4d23-89c0-73dc1eb801ef":{"name":"animation_1","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"JyoVfEgofyATvNJEmRT8zRFmuUHAOlfz","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/5c7c1bb1-575f-4d23-89c0-73dc1eb801ef.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life=5;
var cactus,shell,she;
var fish;

var ocean=createSprite(200,200);
ocean.setAnimation("ocean");
var cactus=createSprite(150,150,100,100);
cactus.setAnimation("cactus");
var shell=createSprite(230,190,150,100);
shell.setAnimation("shell");
var she=createSprite(300,150,100,100);
she.setAnimation("she");
var fish=createSprite(40,140,210,170);
var line=createSprite(350,150,200,270);
line.setAnimation("line");



  
line.setAnimation("line");
line.scale=.90;
fish.setAnimation("fish");
fish.scale=.1;
cactus.setAnimation("cactus");
cactus.scale=.1;
shell.setAnimation("shell");
shell.scale=.1;
she.setAnimation("she");
she.scale=.1;

//Add the velocity to move the plants
cactus.velocityY=-8
shell.velocityY=8;
she.velocityY=-8;

function draw(){
 


createEdgeSprites();




cactus.bounceOff(edges);
she.bounceOff(edges);
shell.bounceOff(edges);

// create bounceoff function to make the plants bounceoff the boundaries


if(fish.isTouching(shell)||fish.isTouching(she)||fish.isTouching(cactus)){
   playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3");
}
if(fish.isTouching(line)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3");
  fish.x=200;
  fish.y=345;
  life=life+1;
}
if(keyDown(LEFT)){
  fish.x=fish.x-2;
  }
if(keyDown(RIGHT)){
  fish.x=fish.x+2;
}
if(keyDown(DOWN_ARROW)){
  fish.y=fish.y+2;
}
if(keyDown(UP_ARROW)){
  fish.y=fish.y-2;
}
if(
     fish.isTouching(shell)||
     fish.isTouching(she)||
     fish.isTouching(cactus))
  {  
    fish.x = 20;
    fish.y = 190;
     life = life + 1;
  }
  
if(life ==0){
     fill("black");
     textSize(10);
    text("GAME OVER!!!",100,200);
    shell.velocityY=0;
    she.velocityY=0;
    cactus.velocityY=0;

   
  }
  if(fish.x>375){
    
    fill("pink");
    textSize(15);
    text("YOU WIN!!",500,200);
    cactus.velocityY=0;
    shell.velocityY=0;
    she.velocityY=0;
    
    
   }
















drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
